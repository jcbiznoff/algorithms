/*******************************************************************************
+
+  LEDA 6.3  
+
+
+  limits.h
+
+
+  Copyright (c) 1995-2010
+  by Algorithmic Solutions Software GmbH
+  All rights reserved.
+ 
*******************************************************************************/


#define LEDA_STD_INCLUDE

#if defined(LEDA_STD_HEADERS)
#include <limits>
#else
#include <limits.h>
#endif

#undef LEDA_STD_INCLUDE
