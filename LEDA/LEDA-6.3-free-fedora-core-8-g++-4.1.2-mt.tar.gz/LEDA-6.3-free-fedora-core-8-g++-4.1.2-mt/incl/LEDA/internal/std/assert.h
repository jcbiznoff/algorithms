/*******************************************************************************
+
+  LEDA 6.3  
+
+
+  assert.h
+
+
+  Copyright (c) 1995-2010
+  by Algorithmic Solutions Software GmbH
+  All rights reserved.
+ 
*******************************************************************************/



#define LEDA_STD_INCLUDE
#if defined(LEDA_STD_HEADERS)
#include <cassert>
#else
#include <assert.h>
#endif
#undef LEDA_STD_INCLUDE

