/*******************************************************************************
+
+  LEDA 6.3  
+
+
+  REDEFINE_NAMES.h
+
+
+  Copyright (c) 1995-2010
+  by Algorithmic Solutions Software GmbH
+  All rights reserved.
+ 
*******************************************************************************/


// for backward compatibility
// please use <LEDA/internal/PREAMBLE.h>

#include <LEDA/internal/PREAMBLE.h>

